from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("staff.html").resolve().as_uri()
names=["Cathartes_14_Cuadrilla_Inicio","Cathartes_15_Cuadrilla_Rutas","Cathartes_16_Cuadrilla_Intervenciones","Cathartes_17_Cuadrilla_Mapa","Cathartes_18_Operario_Inicio","Cathartes_19_Operario_Instalacion","Cathartes_20_Operario_Informe"]
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1240,"height":900}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(2000)
    pages=pg.query_selector_all(".page")
    print("pages:",len(pages))
    for el,name in zip(pages,names):
        el.screenshot(path=name+".png")
    b.close()
print("done")
