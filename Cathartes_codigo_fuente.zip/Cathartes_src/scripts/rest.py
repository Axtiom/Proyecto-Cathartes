from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("estadisticas.html").resolve().as_uri()
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1240,"height":900}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(1800)
    pg.screenshot(path="Cathartes_06_Estadisticas.png", full_page=True)
    b.close()
print("ok")
