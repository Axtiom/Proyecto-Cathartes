from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("vecino.html").resolve().as_uri()
names=["Cathartes_08_Vecino_Inicio","Cathartes_09_Vecino_MisIncidencias","Cathartes_10_Vecino_Mapa","Cathartes_11_Vecino_Saldo","Cathartes_12_Vecino_Recompensas","Cathartes_13_Vecino_Perfil"]
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1240,"height":900}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(2000)
    pages=pg.query_selector_all(".page")
    print("pages found:",len(pages))
    for el,name in zip(pages,names):
        el.screenshot(path=name+".png")
    b.close()
print("done")
