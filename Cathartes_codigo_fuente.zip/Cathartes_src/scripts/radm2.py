from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("admin2.html").resolve().as_uri()
names=["Cathartes_24_Admin_Contenedores","Cathartes_25_Admin_Camiones","Cathartes_26_Admin_Instalaciones","Cathartes_27_Admin_Rutas","Cathartes_28_Admin_Cuadrillas","Cathartes_29_Admin_Recompensas","Cathartes_30_Admin_Informes"]
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1400,"height":920}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(2200)
    pages=pg.query_selector_all(".page")
    print("pages:",len(pages))
    for el,name in zip(pages,names):
        el.screenshot(path=name+".png")
    b.close()
print("done")
