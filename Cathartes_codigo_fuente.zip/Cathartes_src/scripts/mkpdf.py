from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from PIL import Image
import os

BG   = HexColor("#0B1020")
CARD = HexColor("#141B2E")
GREEN= HexColor("#2FBF71")
LAV  = HexColor("#A9B4F0")
TEXT = HexColor("#E7EAF5")
DIM  = HexColor("#9BA1C4")
DIM2 = HexColor("#6E72A0")
LINE = HexColor("#242C46")

# (archivo, titulo, universo, RF)
S = [
 ("Cathartes_01_Landing.png","Landing pública","0 · Público","RF-49, 50, 51, 53"),
 ("Cathartes_02_Registro.png","Registro de cuenta","0 · Público","RF-1, 50"),
 ("Cathartes_03_Login.png","Inicio de sesión","0 · Público","RF-2, 3"),
 ("Cathartes_04_2FA.png","Verificación en dos pasos","0 · Público","RNF-8"),
 ("Cathartes_05_Recuperar.png","Recuperar contraseña","0 · Público","RF-9"),
 ("Cathartes_06_Estadisticas.png","Estadísticas públicas","0 · Público","RF-41, 53"),
 ("Cathartes_07_Vecino_Reportar.png","Reportar incidencia","1 · Vecino","RF-18 · foto obligatoria"),
 ("Cathartes_08_Vecino_Inicio.png","Inicio del vecino","1 · Vecino","RF-3, 58"),
 ("Cathartes_09_Vecino_MisIncidencias.png","Mis incidencias y seguimiento","1 · Vecino","RF-22, 43, 44"),
 ("Cathartes_10_Vecino_Mapa.png","Mapa de contenedores","1 · Vecino","RF-35, 36, 37"),
 ("Cathartes_11_Vecino_Saldo.png","Mi saldo de puntos","1 · Vecino","RF-58 · RN5 (150 pts)"),
 ("Cathartes_12_Vecino_Recompensas.png","Catálogo de recompensas","1 · Vecino","RF-60, 61, 62"),
 ("Cathartes_13_Vecino_Perfil.png","Mi perfil y personalización","1 · Vecino","RF-8"),
 ("Cathartes_14_Cuadrilla_Inicio.png","Inicio de cuadrilla","2 · Cuadrilla","RF-3"),
 ("Cathartes_15_Cuadrilla_Rutas.png","Mis rutas asignadas","2 · Cuadrilla","RF-33, 34"),
 ("Cathartes_16_Cuadrilla_Intervenciones.png","Intervenciones y repuestos","2 · Cuadrilla","RF-14, 15 · intervencion, usa"),
 ("Cathartes_17_Cuadrilla_Mapa.png","Mapa operativo de cuadrilla","2 · Cuadrilla","RF-35"),
 ("Cathartes_18_Operario_Inicio.png","Inicio de operario","3 · Operario","RF-3"),
 ("Cathartes_19_Operario_Instalacion.png","Mi instalación y maquinaria","3 · Operario","RF-28 · maquinaria"),
 ("Cathartes_20_Operario_Informe.png","Informe de ocupación","3 · Operario","RF-39, 47"),
 ("Cathartes_21_Admin_Dashboard.png","Dashboard y mapa operativo","4 · Admin","RF-55 · alertas RF-30"),
 ("Cathartes_22_Admin_Usuarios.png","Gestión de usuarios","4 · Admin","RF-4, 5, 6, 7, 10, 11, 12"),
 ("Cathartes_23_Admin_Incidencias.png","Gestión de incidencias","4 · Admin","RF-19, 20, 21, 22"),
 ("Cathartes_24_Admin_Contenedores.png","Gestión de contenedores","4 · Admin","RF-13, 16, 17"),
 ("Cathartes_25_Admin_Camiones.png","Gestión de camiones","4 · Admin","RF-24, 25, 26"),
 ("Cathartes_26_Admin_Instalaciones.png","Gestión de instalaciones","4 · Admin","RF-27, 29, 30"),
 ("Cathartes_27_Admin_Rutas.png","Gestión de rutas","4 · Admin","RF-31, 32, 33"),
 ("Cathartes_28_Admin_Cuadrillas.png","Gestión de cuadrillas","4 · Admin","RF-23"),
 ("Cathartes_29_Admin_Recompensas.png","Gestión de recompensas","4 · Admin","RF-59"),
 ("Cathartes_30_Admin_Informes.png","Informes y proyecciones","4 · Admin","RF-38, 39, 40, 42"),
]

BIRD = [
 [(60,34),(74,26),(90,25),(106,30)],
]

def bird(c, x, y, w, col=GREEN):
    """Buitre simplificado dibujado a escala."""
    h = w*0.6
    c.setFillColor(col)
    p = c.beginPath()
    # ala derecha
    p.moveTo(x, y)
    p.curveTo(x+w*0.12, y+w*0.07, x+w*0.25, y+w*0.075, x+w*0.38, y+w*0.035)
    p.curveTo(x+w*0.34, y+w*0.03, x+w*0.35, y+w*0.005, x+w*0.32, y+w*0.005)
    p.curveTo(x+w*0.29, y+w*0.005, x+w*0.30, y-w*0.02, x+w*0.27, y-w*0.015)
    p.curveTo(x+w*0.24, y-w*0.015, x+w*0.24, y-w*0.03, x+w*0.21, y-w*0.03)
    p.curveTo(x+w*0.17, y-w*0.03, x+w*0.11, y-w*0.025, x+w*0.02, y-w*0.05)
    p.close(); c.drawPath(p, fill=1, stroke=0)
    # ala izquierda (espejo)
    p = c.beginPath()
    p.moveTo(x, y)
    p.curveTo(x-w*0.12, y+w*0.07, x-w*0.25, y+w*0.075, x-w*0.38, y+w*0.035)
    p.curveTo(x-w*0.34, y+w*0.03, x-w*0.35, y+w*0.005, x-w*0.32, y+w*0.005)
    p.curveTo(x-w*0.29, y+w*0.005, x-w*0.30, y-w*0.02, x-w*0.27, y-w*0.015)
    p.curveTo(x-w*0.24, y-w*0.015, x-w*0.24, y-w*0.03, x-w*0.21, y-w*0.03)
    p.curveTo(x-w*0.17, y-w*0.03, x-w*0.11, y-w*0.025, x-w*0.02, y-w*0.05)
    p.close(); c.drawPath(p, fill=1, stroke=0)
    # cuerpo
    p = c.beginPath()
    p.moveTo(x, y+w*0.13)
    p.curveTo(x+w*0.035, y+w*0.06, x+w*0.04, y+w*0.025, x+w*0.033, y-w*0.005)
    p.curveTo(x+w*0.025, y-w*0.06, x+w*0.017, y-w*0.10, x, y-w*0.155)
    p.curveTo(x-w*0.017, y-w*0.10, x-w*0.025, y-w*0.06, x-w*0.033, y-w*0.005)
    p.curveTo(x-w*0.04, y+w*0.025, x-w*0.035, y+w*0.06, x, y+w*0.13)
    p.close(); c.drawPath(p, fill=1, stroke=0)

A4W, A4H = 595.28, 841.89
LAND = (A4H, A4W)
PORT = (A4W, A4H)

out = "/mnt/user-data/outputs/Cathartes_Maqueta_Figma.pdf"
c = canvas.Canvas(out, pagesize=PORT)
c.setTitle("Cathartes — Maqueta del sistema")
c.setAuthor("Axtiom")
c.setSubject("SiGeRU / Cathartes — Maqueta de interfaz (30 pantallas)")

# ---------- PORTADA ----------
W,H = PORT
c.setFillColor(BG); c.rect(0,0,W,H,fill=1,stroke=0)
bird(c, W/2, H-215, 130)
c.setFillColor(TEXT); c.setFont("Helvetica-Bold", 40)
c.drawCentredString(W/2, H-290, "CATHARTES")
c.setFillColor(GREEN); c.setLineWidth(2)
c.line(W/2-40, H-308, W/2+40, H-308)
c.setFillColor(TEXT); c.setFont("Helvetica-Bold", 21)
c.drawCentredString(W/2, H-350, "Maqueta del sistema")
c.setFillColor(DIM); c.setFont("Helvetica", 13)
c.drawCentredString(W/2, H-374, "Sistema de Gestión de Residuos Urbanos — SiGeRU")
c.setFillColor(DIM2); c.setFont("Helvetica", 11)
c.drawCentredString(W/2, H-396, "30 pantallas · 5 universos de navegación")

c.setFillColor(CARD); c.roundRect(W/2-190, H-560, 380, 132, 10, fill=1, stroke=0)
rows = [("Universo 0 · Público","6 pantallas"),("Universo 1 · Vecino","7 pantallas"),
        ("Universo 2 · Cuadrilla","4 pantallas"),("Universo 3 · Operario","3 pantallas"),
        ("Universo 4 · Administración","10 pantallas")]
yy = H-455
for a,b in rows:
    c.setFillColor(DIM); c.setFont("Helvetica", 10.5); c.drawString(W/2-165, yy, a)
    c.setFillColor(LAV); c.setFont("Helvetica-Bold", 10.5); c.drawRightString(W/2+165, yy, b)
    yy -= 23

c.setFillColor(DIM2); c.setFont("Helvetica", 10)
c.drawCentredString(W/2, 96, "Axtiom — Proyecto de Pasaje de Grado 2026")
c.drawCentredString(W/2, 80, "ESI Buceo · Montevideo, Uruguay")
c.showPage()

# ---------- ÍNDICE ----------
c.setPageSize(PORT); W,H = PORT
c.setFillColor(BG); c.rect(0,0,W,H,fill=1,stroke=0)
c.setFillColor(TEXT); c.setFont("Helvetica-Bold", 24)
c.drawString(56, H-70, "Índice de pantallas")
c.setStrokeColor(LINE); c.setLineWidth(1); c.line(56, H-84, W-56, H-84)

y = H-116
last_u = None
for i,(f,t,u,rf) in enumerate(S, start=1):
    if u != last_u:
        if last_u is not None: y -= 9
        c.setFillColor(GREEN); c.setFont("Helvetica-Bold", 9)
        c.drawString(56, y, "UNIVERSO " + u.split(" · ")[0] + "  ·  " + u.split(" · ")[1].upper())
        y -= 16; last_u = u
    c.setFillColor(LAV); c.setFont("Helvetica-Bold", 9.5)
    c.drawString(56, y, f"{i:02d}")
    c.setFillColor(TEXT); c.setFont("Helvetica", 10.5)
    c.drawString(80, y, t)
    c.setFillColor(DIM2); c.setFont("Helvetica", 8.5)
    c.drawRightString(W-56, y, rf)
    y -= 17
c.setFillColor(DIM2); c.setFont("Helvetica", 8.5)
c.drawCentredString(W/2, 44, "Cathartes — Maqueta del sistema · Axtiom 2026")
c.showPage()

# ---------- PANTALLAS ----------
for i,(f,t,u,rf) in enumerate(S, start=1):
    im = Image.open(f); iw, ih = im.size
    ratio = ih/iw
    pagesize = PORT if ratio > 0.95 else LAND
    c.setPageSize(pagesize); W,H = pagesize
    c.setFillColor(BG); c.rect(0,0,W,H,fill=1,stroke=0)

    # encabezado
    bird(c, 62, H-46, 26)
    c.setFillColor(LAV); c.setFont("Helvetica-Bold", 10)
    c.drawString(84, H-50, f"{i:02d}")
    c.setFillColor(TEXT); c.setFont("Helvetica-Bold", 14)
    c.drawString(104, H-51, t)
    c.setFillColor(DIM2); c.setFont("Helvetica", 9)
    c.drawRightString(W-56, H-42, "Universo " + u)
    c.setFillColor(GREEN); c.setFont("Helvetica", 8.5)
    c.drawRightString(W-56, H-56, rf)
    c.setStrokeColor(LINE); c.setLineWidth(1); c.line(56, H-68, W-56, H-68)

    # imagen
    top, bot, side = H-84, 46, 56
    aw, ah = W-side*2, top-bot
    sc = min(aw/iw, ah/ih)
    dw, dh = iw*sc, ih*sc
    x, y = (W-dw)/2, bot + (ah-dh)/2
    c.setFillColor(LINE)
    c.roundRect(x-1.5, y-1.5, dw+3, dh+3, 5, fill=1, stroke=0)
    c.drawImage(ImageReader(f), x, y, dw, dh, mask=None)

    c.setFillColor(DIM2); c.setFont("Helvetica", 8)
    c.drawString(56, 30, "Cathartes — Maqueta del sistema")
    c.drawRightString(W-56, 30, f"{i} / 30")
    c.showPage()

c.save()
print("PDF generado:", out, os.path.getsize(out)//1024, "KB")
