from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("auth.html").resolve().as_uri()
screens={"s_registro":"Cathartes_02_Registro","s_login":"Cathartes_03_Login","s_2fa":"Cathartes_04_2FA","s_recuperar":"Cathartes_05_Recuperar"}
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1120,"height":760}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(2000)
    for sid,name in screens.items():
        el=pg.query_selector("#"+sid)
        el.screenshot(path=name+".png")
        print("rendered",name)
    b.close()
