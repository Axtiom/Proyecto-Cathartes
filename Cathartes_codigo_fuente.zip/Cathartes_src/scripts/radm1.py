from playwright.sync_api import sync_playwright
import pathlib
url=pathlib.Path("admin1.html").resolve().as_uri()
names=["Cathartes_21_Admin_Dashboard","Cathartes_22_Admin_Usuarios","Cathartes_23_Admin_Incidencias"]
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1400,"height":940}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(2000)
    pages=pg.query_selector_all(".page")
    print("pages:",len(pages))
    for el,name in zip(pages,names):
        el.screenshot(path=name+".png")
    b.close()
print("done")
