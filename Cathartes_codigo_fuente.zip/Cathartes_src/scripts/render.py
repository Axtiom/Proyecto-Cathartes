from playwright.sync_api import sync_playwright
import pathlib
url = pathlib.Path("landing.html").resolve().as_uri()
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width":1280,"height":900}, device_scale_factor=2)
    pg.goto(url)
    pg.wait_for_timeout(2500)  # let fonts + image load
    pg.screenshot(path="Cathartes_01_Landing.png", full_page=True)
    b.close()
print("rendered")
