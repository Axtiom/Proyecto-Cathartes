# Cathartes — Maqueta del sistema (código fuente)

Código HTML/CSS de las 30 pantallas de la maqueta de **SiGeRU / Cathartes**.
Todo es HTML + CSS puro, sin frameworks ni dependencias. Cada archivo se abre
directamente en el navegador (doble clic).

---

## Paleta del sistema (híbrido)

Definida como variables CSS en el `:root` de cada archivo. Cambiar el valor ahí
lo actualiza en toda la pantalla.

| Variable | Hex | Uso |
|---|---|---|
| `--bg` | `#0B1020` | Fondo de página (azul-noche) |
| `--card` | `#141B2E` | Tarjetas y paneles |
| `--muted` | `#1B2440` | Inputs, superficies elevadas |
| `--side` | `#0D1324` | Sidebar del admin |
| `--green` | `#2FBF71` | Marca · acción principal |
| `--lav` | `#A9B4F0` | Acento lavanda |
| `--text` | `#E7EAF5` | Texto principal |
| `--dim` | `#9BA1C4` | Texto secundario |
| `--dim2` | `#6E72A0` | Texto terciario |

### Colores de estado

| Variable | Hex | Significado |
|---|---|---|
| `--green` | `#2FBF71` | Funcional · validada · resuelta |
| `--amber` | `#F5B54A` | Desbordado · pendiente · mantenimiento |
| `--red` | `#F58A8A` | Roto / no funcional · rechazada |
| `--blue` | `#6FB2FB` | En curso · falta de recolección |
| `--gray` | `#5E6690` | Dado de baja |

## Tipografías (Google Fonts)

- **Barlow Condensed** — títulos y números grandes
- **DM Sans** — cuerpo de texto
- **JetBrains Mono** — IDs, fechas, datos numéricos

---

## Estructura

```
pantallas/
  01_landing.html                              → Universo 0 · Landing
  02-05_registro_login_2fa_recuperar.html      → Universo 0 · Acceso (4 pantallas)
  06_estadisticas.html                         → Universo 0 · Estadísticas públicas
  07_vecino_reportar.html                      → Universo 1 · Reportar incidencia
  08-13_vecino.html                            → Universo 1 · Vecino (6 pantallas)
  14-20_cuadrilla_operario.html                → Universos 2 y 3 (7 pantallas)
  21-23_admin_dashboard_usuarios_incidencias   → Universo 4 · Núcleo (3 pantallas)
  24-30_admin_gestion.html                     → Universo 4 · Gestión (7 pantallas)

logo/
  cathartes_emblema.svg   → emblema completo (buitre + camión + anillos)
  cathartes_buitre.svg    → buitre solo (favicon y usos chicos)

scripts/
  render*.py, r*.py       → renderizan cada HTML a PNG (Playwright)
  mkpdf.py                → arma el PDF de 30 páginas (reportlab)
```

Los archivos que agrupan varias pantallas usan `<div class="page">` por pantalla,
apiladas verticalmente, y un `<script>` al final que inyecta la barra superior /
sidebar y el footer en cada una (para no repetir el markup).

---

## Cómo se renderizan a PNG

Requiere Python con `playwright` y Chromium instalado:

```bash
pip install playwright
playwright install chromium
python3 scripts/rvall.py
```

Cada script apunta a su HTML y guarda un PNG por pantalla en alta resolución
(`device_scale_factor=2`). Para el PDF: `python3 scripts/mkpdf.py`.

**Alternativa sin scripts:** abrir el HTML en el navegador y usar
`Ctrl+P → Guardar como PDF`, o una extensión de captura de página completa.

---

## Notas

- **Conexión a internet:** los HTML cargan las tipografías desde Google Fonts, y
  `01_landing.html` usa además una foto de Unsplash. Sin internet, el navegador
  cae a fuentes por defecto y la foto no aparece (los PNG ya renderizados no
  tienen este problema).
- **Iconografía:** todos los íconos son SVG inline, sin librerías externas.
- **Bootstrap:** la maqueta es conceptual y está pensada desktop-first. La
  implementación responsive con Bootstrap es posterior.
- El logo es un boceto para la maqueta; la versión definitiva se ajusta aparte.

---

Axtiom — Proyecto de Pasaje de Grado 2026 · ESI Buceo, Montevideo
